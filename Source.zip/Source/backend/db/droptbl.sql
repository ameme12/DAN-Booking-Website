
DROP TABLE BookingAttachment;
DROP TABLE Votes;
DROP TABLE Reserve;
DROP TABLE Dates;
DROP TABLE AvailableSlots;
DROP TABLE Attachments;
DROP TABLE Notification;
DROP TABLE NotificationTemplate;
DROP TABLE Poll;
DROP TABLE Booking;
DROP TABLE Members;
DROP TABLE User;



